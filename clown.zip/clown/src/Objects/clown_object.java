/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 *
 * @author Youssef
 */
public class clown_object extends ImageObject {
		public clown_object(int posX, int posY, String path) {
			super(posX, posY, path,0);
		}
		public clown_object(int posX, int posY, String path,int type) {
			super(posX, posY, path,type);
		}
		@Override
		public void setY(int y){
		}
	}
    
    



