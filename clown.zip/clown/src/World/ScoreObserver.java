/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package World;

/**
 *
 * @author Youssef
 */
public class ScoreObserver {
    
    
     static int score=0;
     public  void updatescore(){
     
     score++;
     
     }

    public  int getScore() {
        return score;
    }

}
